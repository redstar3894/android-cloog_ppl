/* Generated from ../../../git/cloog/test/reservoir/two.cloog by CLooG 0.14.0-253-ge300ff5 gmp bits in 0.00s. */
for (i=0;i<=1;i++) {
  if ((i+1)%2 == 0) {
    S1(i,(-i+3)/2,(i+9)/2);
  }
}
