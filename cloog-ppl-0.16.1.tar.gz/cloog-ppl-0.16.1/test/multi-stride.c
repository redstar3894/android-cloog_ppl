/* Generated from ../../../git/cloog/test/multi-stride.cloog by CLooG 0.14.0-253-ge300ff5 gmp bits in 0.00s. */
for (i=2;i<=100;i+=6) {
}
