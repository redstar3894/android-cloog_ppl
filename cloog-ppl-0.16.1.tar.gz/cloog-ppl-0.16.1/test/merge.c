/* Generated from ../../../git/cloog/test/merge.cloog by CLooG 0.14.0-249-g82c3b0f gmp bits in 0.00s. */
for (c1=0;c1<=10;c1++) {
  if (c1 == 0) {
    S1(0);
  }
  if (c1 >= 2) {
    S2(c1);
  }
  S3(c1);
}
