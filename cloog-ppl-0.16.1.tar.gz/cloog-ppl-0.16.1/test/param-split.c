/* Generated from ../../../git/cloog-polylib/cloog-core/test/param-split.cloog by CLooG 0.14.0-278-gcf1f323 gmp bits. */
if (M <= -1) {
  S2(0);
}
for (i=0;i<=M;i++) {
  S1(i);
  if (i == 0) {
    S2(i);
  }
}
