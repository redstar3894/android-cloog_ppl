/* Generated from ../../../git/cloog/test/iftest2.cloog by CLooG 0.14.0-264-gca47033 gmp bits in 0.00s. */
if ((M >= 1) && (N >= 1)) {
  for (i=1;i<=N;i++) {
    for (j=1;j<=M;j++) {
      S1(i,j);
    }
  }
}
