/* Generated from ../../../git/cloog/test/multi-stride2.cloog by CLooG 0.14.0-136-gb91ef26 gmp bits in 0.01s. */
for (i=5;i<=100;i+=6) {
  S1(i,(i-1)/2,(i-2)/3) ;
}
