/* Generated from ../../../git/cloog/test/./reservoir/jacobi2.cloog by CLooG 0.14.0-136-gb91ef26 gmp bits in 0.00s. */
for (c2=0;c2<=M-1;c2++) {
  for (c4=0;c4<=M-1;c4++) {
    S1(c2,c4) ;
  }
}
