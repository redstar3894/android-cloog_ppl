/* Generated from ../../../git/cloog/test/merge.cloog by CLooG 0.14.0-238-gb1cb779 gmp bits in 0.00s. */
S1(0);
for (c1=0;c1<=10;c1++) {
  if (c1 >= 2) {
    S2(c1);
  }
  S3(c1);
}
