/* Generated from ../../../git/cloog/test/stride3.cloog by CLooG 0.14.0-291-g5879c32 gmp bits in 0.00s. */
if ((m <= n) && (n >= 1)) {
  for (p1=max(50,50*m);p1<=50*n;p1+=50) {
    S1(p1/50);
  }
}
