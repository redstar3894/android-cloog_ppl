/* Generated from ../../../git/cloog/test/double.cloog by CLooG 0.14.0-136-gb91ef26 gmp bits in 0.01s. */
if (M >= 0) {
  for (i=0;i<=M;i++) {
    S1(i) ;
    for (j=0;j<=N;j++) {
      S2(i,j) ;
      S3(i,j) ;
    }
    S4(i) ;
  }
}
