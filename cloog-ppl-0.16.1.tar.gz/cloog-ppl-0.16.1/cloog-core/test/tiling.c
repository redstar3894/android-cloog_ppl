/* Generated from ../../../git/cloog/test/tiling.cloog by CLooG 0.14.0-136-gb91ef26 gmp bits in 0.00s. */
for (ii=0;ii<=floord(n,10);ii++) {
  for (i=10*ii;i<=min(n,10*ii+9);i++) {
    S1(ii,i) ;
  }
}
