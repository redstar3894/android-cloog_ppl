/* Generated from ../../../git/cloog/test/1point-2.cloog by CLooG 0.14.0-136-gb91ef26 gmp bits in 0.01s. */
S1(2*M,N+2) ;
