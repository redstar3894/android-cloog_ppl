#ifndef CLOOG_PPL_BACKEND_H
#define CLOOG_PPL_BACKEND_H

struct cloogbackend {
};

#endif /* define _H */
